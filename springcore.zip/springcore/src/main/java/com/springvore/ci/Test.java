package com.springvore.ci;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/springvore/ci/ciconfig.xml");
		
		Person person=(Person) ctx.getBean("person");
		System.out.println(person);
		
		Addition add =(Addition)ctx.getBean("add");
		System.out.println(add);
	}

}
