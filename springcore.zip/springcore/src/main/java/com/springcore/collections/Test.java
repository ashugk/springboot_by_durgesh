package com.springcore.collections;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

public class Test {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		ApplicationContext ctx = new ClassPathXmlApplicationContext("com/springcore/collections/configCollactiom.xml");
		Emp empObj= (Emp)ctx.getBean("emp1");
		System.out.println(empObj.getEmployeeName());
		System.out.println(empObj.getPhones());
		System.out.println(empObj.getAddresses());
		System.out.println(empObj.getCourses());
		System.out.println(empObj.getProps());
	}

}
